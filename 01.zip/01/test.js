function roop(n){
    if (n === 0) {
        return 0;
    }else if(n === 1){
        return 0;
    }else{
        return (roop(n-1) + roop(n-2));
    }
}
roop(10);
